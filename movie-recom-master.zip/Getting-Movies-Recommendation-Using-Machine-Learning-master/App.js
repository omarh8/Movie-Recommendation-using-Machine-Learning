import React, { Component } from "react";
import Layout from "./containers/Layout";

class App extends Component {
  render() {
    return <Layout />;
  }
}

export default App;
