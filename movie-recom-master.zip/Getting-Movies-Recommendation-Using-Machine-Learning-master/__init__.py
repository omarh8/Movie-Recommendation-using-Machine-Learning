"""Config for running unittest"""
config_name = 'testing'